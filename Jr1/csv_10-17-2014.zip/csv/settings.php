<?php
include "../config.php";

$host = constant('DB_HOSTNAME');
$user = constant('DB_USERNAME');
$password = constant('DB_PASSWORD');
$database = constant('DB_DATABASE');
$db_prefix = constant('DB_PREFIX');

?>