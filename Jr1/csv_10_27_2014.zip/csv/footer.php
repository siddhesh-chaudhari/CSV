<footer class="footer-class">
	<div style="margin-top:20px;padding:10px;float:left;">
		<a href="http://www.nsmedia.in" target="_blank"><img src="logo.png"></a>
	</div>
	<div class="footer-credit" style="float:left;">
		Powered by : <a href="http://www.nsmedia.in" target="_blank">NS Media solutions</a><br>
		Copyright &copy; 2014. All Rights Reserved.<br>
		<span style="font-size:14px;text-shadow:1px 1px 0px #AAA;">Developer: Siddhesh Chaudhari.</span>
	</div>
	<div class="footer-social">
		<a href="https://www.facebook.com/nsmedia.in" target="_blank"><img src="fb.png"></a>
	</div>
</footer>